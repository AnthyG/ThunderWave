# emojipy
Python library for working with emoji
